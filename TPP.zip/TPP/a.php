<?php
session_start();

echo stripos("abcdefghijk","agg");

?>