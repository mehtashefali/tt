</br></br></br>
<div class="col-sm-12">
</br>
				
                        <header class="panel-heading">
                           Opportunity
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form">
                                <div class="form-group">
                                    
							
								
								
								<div class="form-group">
                                    <label for="">Company Name</label>
									 <Select class="form-control" id="">
									<option value="" select>TCS</option>
									<option value="">Wipro</option>
									</select>
                                </div>
								<div class="form-group">
                                    <label for="">Opportunity Type</label>
									 <Select class="form-control" id="">
									<option value="" select>Job</option>
									<option value="">internship</option>
									</select>
                                </div>
								
								<div class="form-group">
                                    <label for="">Company Type</label>
									 <Select class="form-control" id="">
									<option value="" select>IT</option>
									<option value="">Civil</option>
									</select>
                                </div>
								<div class="form-group">
                                    <label for="">Job Structure</label>
									 <Select class="form-control" id="">
									<option value="" select>Full-Time</option>
									<option value="">Part-Time</option>
									</select>
                                </div>
								
								
							
								<div class="form-group">
                                    <label for="">Post</label>
                                    <Select class="form-control" id="">
									<option value="" select>Trainee Engineers</option>
									<option value="Quantitative">Software Engineer</option>
									</select>
                                </div>
								
                               <div class="form-group">
                                    <label for="exampleInputPassword1">Data</label>
                                    <textarea class="form-control" id="" placeholder=""></textarea>
                                </div>
								<div class="form-group">
                                    <label for="">Date</label>
									<input type="text" class="form-control" id="" placeholder="">

                                </div>
								<div class="form-group">
                                    <label for="">Time</label>
									<input type="text" class="form-control" id="" placeholder="">

                                </div>
								
								

                                <button type="submit" class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>

			
			
					
					


<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
            <th>Company_Name</th>
            <th>Opportunity_Type</th>
			            <th>Company_Type</th>
			            <th>Job_Structure</th>

            <th>Post</th>
			<th>Data</th>
			<th>Date</th>
			<th>Time</th>




			           

			<th>Action</th>

          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>TCS</td>
            <td>Intrenship</td>
			            <td>IT</td>
						
			            <td>Full-Time</td>

            <td>Trainee Engineer</td>
			            <td>3.5 Lakh</td>

            <td>25th Nov 2020</td>
            <td>10:00 PM</td>

  
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-edit'></td>
		<td><button type='button' onclick='MessageDisplay(this);' class='btn btn-default'>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>


            </div>
        </div>
</div>		