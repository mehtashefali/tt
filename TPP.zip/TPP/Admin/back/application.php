<div class="table-agile-info">
<div class="panel panel-default">

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <thead>
          <tr>
            <th data-breakpoints="xs">Application_ID</th>
            <th>Student_id</th>
            <th>Student_name</th>
			<th>Opprtunity_id</th>
			<th>Opprtunity_title</th>
			<th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr data-expanded="true">
            <td>1</td>
            <td>20180931</td>
            <td>ABC</td>
			<td>12</td>
			<td>Internship</td>
		<td><button type='button' onclick='MessageDisplay(this);' class=''>
        <span class='glyphicon glyphicon-remove'></td>
          
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>


            </div>
        </div>
</div>		