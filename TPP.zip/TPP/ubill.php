
</br></br></br>
<div class="col-sm-12">
</br>
				<div class="table-agile-info">

                        <header class="panel-heading">
						<h1><b>Cart</h1></b>
							</header>		






      <table class="table table-striped b-t b-light">
	          <thead>

  <tr>
    <th>Food Name</th>
    <th>Food Price</th>
    <th>Food Quantity</th>
	<th>Total</th>
  </tr>
          </thead>

  <tr>
    <td>Dosa</td>
    <td>25 Rs/-</td>
	<td>1</td>
	<td>25 Rs/-</td>
	
  </tr>
  
 <tr>
    <td>Pav Bhaji</td>
    <td>25 Rs/-</td>
	<td>1</td>
	<td>25 Rs/-</td>
	
  </tr>
  
  <tr>
    <td>Noodles</td>
    <td>25 Rs/-</td>
	<td>1</td>
	<td>25 Rs/-</td>
	
  </tr>
    <tr>
    <td>Thumbs up</td>
    <td>25 Rs/-</td>
	<td>1</td>
	<td>25 Rs/-</td>
	
  </tr>
  
   <tr>
    <td></td>
    <td><h3 style="background-color:orange;">Total Price<h3></td>
	<td></td>
	<td>100 Rs/-</td>
	
  </tr>
  
</table>

  &nbsp; <button class="mybtn" type="submit" >Placed Order</button>


        </div>
</div>	

 <style>


.mybtn {
	float:right;
	font-size:20px;
	margin-right:10px;
    height:40px;
    border:none;
    background:#00a6b2;
    color:#fff;
    padding:0px 50px;
    border-radius:4px;
    -webkit-border-radius:0 4px 4px 0;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
	font-size: 0.9em;
	color:black;
	border-top: none !important;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
    border-bottom: 1px solid #1e1212 ! important;
}

.panel-heading {
    position: relative;
    height: 57px;
    line-height: 57px;
    letter-spacing: 0.2px;
    color: black;
    font-size: 18px;
    font-weight: 400;
    padding: 0 16px;
    background:#dea1e2;
   border-top-right-radius: 2px;
   border-top-left-radius: 2px; 
    text-transform: uppercase;
    text-align: center;
}
</style>
